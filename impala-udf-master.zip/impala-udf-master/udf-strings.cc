#include "udf-strings.h"
#include <string>
#include <stdio.h>
#include <locale.h>
#include <wctype.h>

void setErrorExit(FunctionContext* context, const char* errMsg, locale_t* old, locale_t* current)
{
	context->SetError(errMsg);
	if (*current != (locale_t)0) freelocale(*current);
	if (*old != (locale_t)0) uselocale(*old);
}

StringVal translate(FunctionContext* context, const StringVal& p_input, const StringVal& p_from, const StringVal& p_to, const StringVal& p_locale) {

	if (p_input.is_null || p_from.is_null || p_to.is_null)
		return StringVal::null();

	int len_input = p_input.len;
	int len_from = p_from.len;
	int len_to = p_to.len;
	int len_locale = p_locale.len;

	if (len_input == 0 || len_from == 0)
		return p_input;

	// Set locale properly
	locale_t old_loc = uselocale((locale_t)0);
	std::string s_locale((const char *)p_locale.ptr, p_locale.len);
	locale_t loc = newlocale(LC_CTYPE_MASK, s_locale.c_str(), (locale_t)0);
	if (loc == (locale_t) 0) {
	    //context->SetError("Error during new locale");
		setErrorExit(context, "Error during new locale", &old_loc, &loc);
		return StringVal::null();
	}
	uselocale(loc);

	std::string s_input((const char *)p_input.ptr, len_input);
	std::string s_from((const char *)p_from.ptr, len_from);
	std::string s_to((const char *)p_to.ptr, len_to);

	// Convert multibyte string to wide-character string
	// (set length +1 to let L'\0' symbol always write to wchar_t)
	const char* c_input = s_input.c_str();
	const char* c_from = s_from.c_str();
	const char* c_to = s_to.c_str();
	mbstate_t state = {0};
	mbrlen(NULL,0,&state);
	size_t len_required = mbsrtowcs(NULL, &c_input, 0, &state);
	wchar_t wc_input[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_w_input = mbsrtowcs(wc_input, &c_input, len_required+1, &state);
	mbrlen(NULL,0,&state);
	len_required = mbsrtowcs(NULL, &c_from, 0, &state);
	wchar_t wc_from[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_w_from = mbsrtowcs(wc_from, &c_from, len_required+1, &state);
	mbrlen(NULL,0,&state);
	len_required = mbsrtowcs(NULL, &c_to, 0, &state);
	wchar_t wc_to[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_w_to = mbsrtowcs(wc_to, &c_to, len_required+1, &state);
	if (len_w_input == (size_t)(-1) || len_w_from == (size_t)(-1) || len_w_to == (size_t)(-1)) {
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		return StringVal::null();
	}
	//wc_input[len_w_input] = L'\0';
	//wc_from[len_w_from] = L'\0';
	//wc_to[len_w_to] = L'\0';

	// Translate
	std::wstring ws_input (wc_input);
	std::wstring ws_from (wc_from);
	std::wstring ws_to (wc_to);
	std::wstring ws_result(L"");

	for (int i = 0; i < len_w_input; i++) {
		bool is_matched = false;

		for (int j = 0; j < len_w_from; j++) {
			if (ws_input[i] == ws_from[j]) {
				is_matched = true;
				if (j < len_w_to)
					ws_result.push_back(ws_to[j]);
				break;
			}
		}

		if (!is_matched)
			ws_result.push_back(ws_input[i]);
	}

	// Convert wide-character string to multibyte string
	// (set length +1 to let '\0' symbol always write to result)
	size_t len_w_result = ws_result.length();
	const wchar_t* wc_res = const_cast<wchar_t*>(ws_result.c_str());
	mbrlen(NULL,0,&state);
	len_required = wcsrtombs(NULL, &wc_res, 0, &state);
	char c_res[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_output = wcsrtombs(c_res, &wc_res, len_required+1, &state);
	if (len_output == (size_t)(-1)) {
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		//context->SetError("Bad symbol");
		//uselocale(old_loc);
		//freelocale(loc);
		return StringVal::null();
	}
	//c_res[len_output] = '\0';

	// Result
	const char* c_result = c_res;
	std::string s_result(c_result);
	size_t len_result = s_result.length();
	StringVal result(context, len_result);
	memcpy(result.ptr, s_result.c_str(), len_result);
	
	uselocale(old_loc);
	freelocale(loc);
	return result;
}

StringVal translate_ruutf8(FunctionContext* context, const StringVal& p_input, const StringVal& p_from, const StringVal& p_to) {
	return translate(context, p_input, p_from, p_to, "ru_RU.utf8");
}

StringVal upper(FunctionContext* context, const StringVal& p_input, const StringVal& p_locale) {

	if (p_input.is_null)
		return StringVal::null();

	int len_input = p_input.len;
	int len_locale = p_locale.len;

	// Set locale properly
	locale_t old_loc = uselocale((locale_t)0);
	std::string s_locale((const char *)p_locale.ptr, p_locale.len);
	locale_t loc = newlocale(LC_CTYPE_MASK, s_locale.c_str(), (locale_t)0);
	if (loc == (locale_t) 0) {
	    //context->SetError("Error during new locale");
	        setErrorExit(context, "Error during new locale", &old_loc, &loc);
		return StringVal::null();
	}
	uselocale(loc);

	std::string s_input((const char *)p_input.ptr, len_input);

	// Convert multibyte string to wide-character string
	// (set length +1 to let L'\0' symbol always write to wchar_t)
	const char* c_input = s_input.c_str();
	mbstate_t state = {0};
	mbrlen(NULL,0,&state);
	size_t len_required = mbsrtowcs(NULL, &c_input, 0, &state);
	wchar_t wc_input[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_w_input = mbsrtowcs(wc_input, &c_input, len_required+1, &state);
	if (len_w_input == (size_t)(-1)) {
		//context->SetError("Bad symbol");
		//uselocale(old_loc);
		//freelocale(loc);
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		return StringVal::null();
	}
	//wc_input[len_w_input] = L'\0';
	
	// To upper case
	std::wstring ws_input (wc_input);
	std::wstring ws_result(L"");

	for (int i = 0; i < len_w_input; i++) {
		ws_result.push_back(towupper(ws_input[i]));
	}

	// Convert wide-character string to multibyte string
	// (set length +1 to let '\0' symbol always write to result)
	size_t len_w_result = ws_result.length();
	const wchar_t* wc_res = const_cast<wchar_t*>(ws_result.c_str());
	mbrlen(NULL,0,&state);
	len_required = wcsrtombs(NULL, &wc_res, 0, &state);
	char c_res[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_output = wcsrtombs(c_res, &wc_res, len_required+1, &state);
	if (len_output == (size_t)(-1)) {
		//context->SetError("Bad symbol");
		//uselocale(old_loc);
		//freelocale(loc);
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		return StringVal::null();
	}
	//c_res[len_output] = '\0';

	// Result
	const char* c_result = c_res;
	std::string s_result(c_result);
	size_t len_result = s_result.length();
	StringVal result(context, len_result);
	memcpy(result.ptr, s_result.c_str(), len_result);

	uselocale(old_loc);
	freelocale(loc);
	return result;
}

StringVal upper_ruutf8(FunctionContext* context, const StringVal& p_input) {
	return upper(context, p_input, "ru_RU.utf8");
}

StringVal lower(FunctionContext* context, const StringVal& p_input, const StringVal& p_locale) {

	if (p_input.is_null)
		return StringVal::null();

	int len_input = p_input.len;
	int len_locale = p_locale.len;

	// Set locale properly
	locale_t old_loc = uselocale((locale_t)0);
	std::string s_locale((const char *)p_locale.ptr, p_locale.len);
	locale_t loc = newlocale(LC_CTYPE_MASK, s_locale.c_str(), (locale_t)0);
	if (loc == (locale_t) 0) {
	    //context->SetError("Error during new locale");
		setErrorExit(context, "Error during new locale", &old_loc, &loc);
		return StringVal::null();
	}
	uselocale(loc);

	std::string s_input((const char *)p_input.ptr, len_input);

	// Convert multibyte string to wide-character string
	// (set length +1 to let L'\0' symbol always write to wchar_t)
	const char* c_input = s_input.c_str();
	mbstate_t state = {0};
	mbrlen(NULL,0,&state);
	size_t len_required = mbsrtowcs(NULL, &c_input, 0, &state);
	wchar_t wc_input[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_w_input = mbsrtowcs(wc_input, &c_input, len_required+1, &state);
	if (len_w_input == (size_t)(-1)) {
		//context->SetError("Bad symbol");
		//uselocale(old_loc);
		//freelocale(loc);
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		return StringVal::null();
	}
	//wc_input[len_w_input] = L'\0';
	
	// To lower case
	std::wstring ws_input (wc_input);
	std::wstring ws_result(L"");

	for (int i = 0; i < len_w_input; i++) {
		ws_result.push_back(towlower(ws_input[i]));
	}

	// Convert wide-character string to multibyte string
	// (set length +1 to let '\0' symbol always write to result)
	size_t len_w_result = ws_result.length();
	const wchar_t* wc_res = const_cast<wchar_t*>(ws_result.c_str());
	mbrlen(NULL,0,&state);
	len_required = wcsrtombs(NULL, &wc_res, 0, &state);
	char c_res[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_output = wcsrtombs(c_res, &wc_res, len_required+1, &state);
	if (len_output == (size_t)(-1)) {
		//context->SetError("Bad symbol");
		//uselocale(old_loc);
		//freelocale(loc);
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		return StringVal::null();
	}
	//c_res[len_output] = '\0';

	// Result
	const char* c_result = c_res;
	std::string s_result(c_result);
	size_t len_result = s_result.length();
	StringVal result(context, len_result);
	memcpy(result.ptr, s_result.c_str(), len_result);
	uselocale(old_loc);
	freelocale(loc);
	return result;
}

StringVal lower_ruutf8(FunctionContext* context, const StringVal& p_input) {
	return lower(context, p_input, "ru_RU.utf8");
}

//StringVal 
IntVal length(FunctionContext* context, const StringVal& p_input, const StringVal& p_locale) {

	if (p_input.is_null)
		return IntVal::null();

	int len_input = p_input.len;
	int len_locale = p_locale.len;

	// Set locale properly
	locale_t old_loc = uselocale((locale_t)0);
	std::string s_locale((const char *)p_locale.ptr, p_locale.len);
	locale_t loc = newlocale(LC_CTYPE_MASK, s_locale.c_str(), (locale_t)0);
	if (loc == (locale_t) 0) {
	    //context->SetError("Error during new locale");
		setErrorExit(context, "Error during new locale", &old_loc, &loc);
		return IntVal::null();
	}
	uselocale(loc);

	std::string s_input((const char *)p_input.ptr, len_input);

	// Convert multibyte string to wide-character string
	// (set length +1 to let L'\0' symbol always write to wchar_t)
	const char* c_input = s_input.c_str();
	mbstate_t state = {0};
	mbrlen(NULL,0,&state);
	size_t len_required = mbsrtowcs(NULL, &c_input, 0, &state);
	wchar_t wc_input[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_w_input = mbsrtowcs(wc_input, &c_input, len_required+1, &state);
	if (len_w_input == (size_t)(-1)) {
		//context->SetError("Bad symbol");
		//uselocale(old_loc);
		//freelocale(loc);
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		return IntVal::null();
	}
	//wc_input[len_w_input] = L'\0';
	
	// Result
	uselocale(old_loc);
	freelocale(loc);
	return IntVal(len_w_input);
}

//StringVal 
IntVal length_ruutf8(FunctionContext* context, const StringVal& p_input) {
	return length(context, p_input, "ru_RU.utf8");
}
// Only for test
StringVal length_ruutf8_str(FunctionContext* context, const StringVal& p_input) {
	IntVal iv_result = length_ruutf8(context, p_input);
	if (iv_result.is_null)
		return StringVal::null();
	
	int32_t i_result = iv_result.val;
	
	char c_result[256]="";
	snprintf(c_result, sizeof(c_result), "%d", i_result);
	std::string s_result(c_result);
	size_t len_result = s_result.length();
	StringVal result(context, len_result);
	memcpy(result.ptr, s_result.c_str(), len_result);
	return result;
}

StringVal substr(FunctionContext* context, const StringVal& p_input, const IntVal& p_from, const IntVal& p_length, const StringVal& p_locale) {

	if (p_input.is_null || p_from.is_null)
		return StringVal::null();

	int len_input = p_input.len;
	int len_locale = p_locale.len;
	int i_from = p_from.val;

	if (len_input == 0)
		return p_input;

	int i_length;
	if(p_length.is_null)
		i_length = len_input;
	else
		i_length = p_length.val;

	if (i_from == 0 || i_length <= 0)
		return StringVal::null();

	// Set locale properly
	locale_t old_loc = uselocale((locale_t)0);
	std::string s_locale((const char *)p_locale.ptr, p_locale.len);
	locale_t loc = newlocale(LC_CTYPE_MASK, s_locale.c_str(), (locale_t)0);
	if (loc == (locale_t) 0) {
	    //context->SetError("Error during new locale");
		setErrorExit(context, "Error during new locale", &old_loc, &loc);
		return StringVal::null();
	}
	uselocale(loc);

	std::string s_input((const char *)p_input.ptr, len_input);

	// Convert multibyte string to wide-character string
	// (set length +1 to let L'\0' symbol always write to wchar_t)
	const char* c_input = s_input.c_str();
	mbstate_t state = {0};
	mbrlen(NULL,0,&state);
	size_t len_required = mbsrtowcs(NULL, &c_input, 0, &state);
	wchar_t wc_input[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_w_input = mbsrtowcs(wc_input, &c_input, len_required+1, &state);
	if (len_w_input == (size_t)(-1)) {
		//context->SetError("Bad symbol");
		//uselocale(old_loc);
		//freelocale(loc);
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		return StringVal::null();
	}
	//wc_input[len_w_input] = L'\0';

	// Substr
	std::wstring ws_input (wc_input);
	std::wstring ws_result(L"");

	if(i_from > 0)
		i_from = i_from - 1; // because 1st is 0th
	if(i_from < 0)
		i_from = len_w_input + i_from;
		//i_from = i_from + 1;
	if ((i_from < 0) || (i_from >= len_w_input))
		return StringVal::null();

	int i_len_max = len_w_input - i_from;
	if (i_length > i_len_max)
		i_length = i_len_max;
	int i_to = i_from + i_length;
	for (int i = i_from; i < i_to; i++)
		ws_result.push_back(ws_input[i]);

	// Convert wide-character string to multibyte string
	// (set length +1 to let '\0' symbol always write to result)
	size_t len_w_result = ws_result.length();
	const wchar_t* wc_res = const_cast<wchar_t*>(ws_result.c_str());
	mbrlen(NULL,0,&state);
	len_required = wcsrtombs(NULL, &wc_res, 0, &state);
	char c_res[len_required+1];
	mbrlen(NULL,0,&state);
	size_t len_output = wcsrtombs(c_res, &wc_res, len_required+1, &state);
	if (len_output == (size_t)(-1)) {
		//context->SetError("Bad symbol");
		//uselocale(old_loc);
		//freelocale(loc);
		setErrorExit(context, "Bad symbol", &old_loc, &loc);
		return StringVal::null();
	}
	//c_res[len_output] = '\0';

	// Result
	const char* c_result = c_res;
	std::string s_result(c_result);
	size_t len_result = s_result.length();
	StringVal result(context, len_result);
	memcpy(result.ptr, s_result.c_str(), len_result);
	uselocale(old_loc);
	freelocale(loc);
	return result;
}

StringVal substr_ruutf8(FunctionContext* context, const StringVal& p_input, const IntVal& p_from, const IntVal& p_length) {
	return substr(context, p_input, p_from, p_length, "ru_RU.utf8");
}
StringVal substr2(FunctionContext* context, const StringVal& p_input, const IntVal& p_from, const StringVal& p_locale) {
	return substr(context, p_input, p_from, IntVal::null(), p_locale);
}
StringVal substr2_ruutf8(FunctionContext* context, const StringVal& p_input, const IntVal& p_from) {
	return substr2(context, p_input, p_from, "ru_RU.utf8");
}
// Only for test
StringVal substr_ruutf8_str(FunctionContext* context, const StringVal& p_input, const StringVal& p_from, const StringVal& p_length) {
	std::string s_from((const char *)p_from.ptr, p_from.len);
	std::string s_length((const char *)p_length.ptr, p_length.len);
	int i_from = atoi(s_from.c_str());
	int i_length = atoi(s_length.c_str());
	return substr_ruutf8(context, p_input, i_from, i_length);
}
StringVal substr2_ruutf8_str(FunctionContext* context, const StringVal& p_input, const StringVal& p_from) {
	std::string s_from((const char *)p_from.ptr, p_from.len);
	int i_from = atoi(s_from.c_str());
	return substr2_ruutf8(context, p_input, i_from);
}