#!/bin/bash

cd `dirname $0`
current_dir=`pwd`

./docker/builder.build.sh

docker run \
	--rm \
	--name impala-udf-build \
	-v $current_dir/build:/build \
	impala-udf-builder \
	cp -r /impala-udf/build/ /
