#ifndef TEST_HELPERS_H
#define TEST_HELPERS_H

#include <iostream>
#include <vector>
#include <boost/function.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <impala_udf/udf-test-harness.h>
#include "udf-dates.h"

using namespace impala;
using namespace impala_udf;


namespace impala_udf {
  // Конкретизируем шаблонную функцию, т.к. TimestampVal не содержит val и обобщенная версия
  // не работает. ValidateUdf вследствии этого не работал. Реалиацию взял из TimeToString.
  // Надо бы заслать патч.
  template<>
  inline std::string DebugString(const TimestampVal& val) {
    using boost::gregorian::date;
    using boost::posix_time::nanoseconds;
    using boost::posix_time::ptime;
    using boost::posix_time::to_iso_extended_string;
    using boost::posix_time::to_simple_string;

    if (val.is_null) return "NULL";
    ptime dttm( *(date*)&val.date );
    dttm += nanoseconds(val.time_of_day);
    std::stringstream ss;
    ss << to_iso_extended_string(dttm.date()) << " " << to_simple_string(dttm.time_of_day());
    return ss.str();
  }
}


// Не нашел возможности написать тест ожидаемой ошибки в UDF, поэтому оформил данную функцю
// на основе ValidateUdf. Пока только для функции с оддним аргументом.
template<typename RET, typename A1>
bool ValidateUdfError(boost::function<RET(FunctionContext*, const A1&)> fn, const A1& a1, 
                      const std::string &expected_error) {
  FunctionContext::TypeDesc return_type;
  std::vector<FunctionContext::TypeDesc> arg_types;
  using boost::scoped_ptr;
  scoped_ptr<FunctionContext> context(UdfTestHarness::CreateTestContext(return_type, arg_types));
  fn(context.get(), a1);
  if (context->has_error()) {
    if (expected_error == context->error_msg()) return true;
    else {
      std::cerr << "UDF did not return the correct error:" << std::endl
                << "  Expected: " << expected_error << std::endl
                << "  Actual: " << context->error_msg() << std::endl;
      return false;
    }
  }
  else {
    std::cerr << "Expected fail, but UDF was successful" << std::endl;
    return false;
  }
}


// Небольшая вспомогательная функция для сборки TimestampVal в тестах
TimestampVal as_timestamp(const int year, const int month, const int day,
                          const int hour, const int minute, const int second) {
  TimestampVal tv;
  boost::gregorian::date dt(year, month, day);
  memcpy(&tv.date, &dt, sizeof(dt));
  tv.time_of_day = boost::posix_time::time_duration(hour, minute, second).ticks();
  return tv;
}


// Возвращает текущее значение счетчика TSC, нужна для замера времени работы UDF-функций:
//   uint64_t start_time = rdtsc(); // в начале UDF
//   uint64_t end_time = rdtsc(); // до return, но по завершению алгоритма
//   std::cout << "TSC diff:" << end_time - start_time << std::endl; // выводим разницу
inline uint64_t rdtsc() {
  unsigned int lo, hi;
  asm volatile ( "rdtsc\n" : "=a" (lo), "=d" (hi) );
  return ((uint64_t)hi << 32) | lo;
}


#endif
