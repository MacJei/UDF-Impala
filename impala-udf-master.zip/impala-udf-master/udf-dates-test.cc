#include <iostream>
#include <impala_udf/udf-test-harness.h>
#include "test-helpers.h"
#include "udf-dates.h"

using namespace impala;
using namespace impala_udf;


int main(int argc, char** argv) {
  bool passed = true;

  /*
    month_begin
  */

  passed &= UdfTestHarness::ValidateUdf<TimestampVal,TimestampVal >(
    MonthBeginTimestamp, TimestampVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,TimestampVal >(
    MonthBeginTimestamp, as_timestamp(2016,2,10,0,0,0), as_timestamp(2016,2,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,TimestampVal >(
    MonthBeginTimestamp, as_timestamp(2017,2,10,0,0,0), as_timestamp(2017,2,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,TimestampVal >(
    MonthBeginTimestamp, as_timestamp(2017,3,14,15,59,59), as_timestamp(2017,3,1,0,0,0)
  );

  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    MonthBeginString, StringVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    MonthBeginString, StringVal("2016-02-10 00:00:00"), as_timestamp(2016,2,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    MonthBeginString, StringVal("2017-02-10 00:00:00"), as_timestamp(2017,2,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    MonthBeginString, StringVal("2017-03-14 15:59:59"), as_timestamp(2017,3,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    MonthBeginString, StringVal("2016-02-10"), as_timestamp(2016,2,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    MonthBeginString, StringVal("2017-02-10"), as_timestamp(2017,2,1,0,0,0)
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthBeginString, StringVal("2017-05-40"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthBeginString, StringVal("2016-20-20"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthBeginString, StringVal("2017-02-DD"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthBeginString, StringVal("2016-02"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthBeginString, StringVal("2017"), "Bad date or timestamp"
  );


  /*
    month_end
  */

  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    MonthEndTimestamp, TimestampVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    MonthEndTimestamp, as_timestamp(2016,2,10,0,0,0), as_timestamp(2016,2,29,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    MonthEndTimestamp, as_timestamp(2017,2,10,0,0,0), as_timestamp(2017,2,28,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    MonthEndTimestamp, as_timestamp(2017,3,14,15,59,59), as_timestamp(2017,3,31,0,0,0)
  );

  passed &= UdfTestHarness::ValidateUdf<TimestampVal, StringVal>(
    MonthEndString, StringVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, StringVal>(
    MonthEndString, StringVal("2016-02-10 00:00:00"), as_timestamp(2016,2,29,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, StringVal>(
    MonthEndString, StringVal("2017-02-10 00:00:00"), as_timestamp(2017,2,28,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, StringVal>(
    MonthEndString, StringVal("2017-03-14 15:59:59"), as_timestamp(2017,3,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, StringVal>(
    MonthEndString, StringVal("2016-02-10"), as_timestamp(2016,2,29,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, StringVal>(
    MonthEndString, StringVal("2017-02-10"), as_timestamp(2017,2,28,0,0,0)
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthEndString, StringVal("2017-05-40"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthEndString, StringVal("2016-20-20"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthEndString, StringVal("2017-02-DD"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthEndString, StringVal("2016-02"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    MonthEndString, StringVal("2017"), "Bad date or timestamp"
  );


  /*
    quarter_begin
  */

  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterBeginTimestamp, TimestampVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterBeginTimestamp, as_timestamp(2016,2,10,0,0,0), as_timestamp(2016,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterBeginTimestamp, as_timestamp(2017,2,10,0,0,0), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterBeginTimestamp, as_timestamp(2017,3,14,15,59,59), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterBeginTimestamp, as_timestamp(2017,5,14,15,59,59), as_timestamp(2017,4,1,0,0,0)
  );

  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterBeginString, StringVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterBeginString, StringVal("2016-02-10 00:00:00"), as_timestamp(2016,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterBeginString, StringVal("2017-02-10 00:00:00"), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterBeginString, StringVal("2017-03-14 15:59:59"), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterBeginString, StringVal("2016-02-10"), as_timestamp(2016,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterBeginString, StringVal("2017-02-10"), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterBeginString, StringVal("2017-05-10"), as_timestamp(2017,4,1,0,0,0)
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterBeginString, StringVal("2017-05-40"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterBeginString, StringVal("2016-20-20"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterBeginString, StringVal("2017-02-DD"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterBeginString, StringVal("2016-02"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterBeginString, StringVal("2017"), "Bad date or timestamp"
  );


  /*
    quarter_end
  */

  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterEndTimestamp, TimestampVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterEndTimestamp, as_timestamp(2016,2,10,0,0,0), as_timestamp(2016,3,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterEndTimestamp, as_timestamp(2017,2,10,0,0,0), as_timestamp(2017,3,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterEndTimestamp, as_timestamp(2017,3,14,15,59,59), as_timestamp(2017,3,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    QuarterEndTimestamp, as_timestamp(2017,5,14,15,59,59), as_timestamp(2017,6,30,0,0,0)
  );

  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterEndString, StringVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterEndString, StringVal("2016-02-10 00:00:00"), as_timestamp(2016,3,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterEndString, StringVal("2017-02-10 00:00:00"), as_timestamp(2017,03,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterEndString, StringVal("2017-03-14 15:59:59"), as_timestamp(2017,3,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterEndString, StringVal("2016-02-10"), as_timestamp(2016,3,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterEndString, StringVal("2017-02-10"), as_timestamp(2017,3,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    QuarterEndString, StringVal("2017-05-10"), as_timestamp(2017,6,30,0,0,0)
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterEndString, StringVal("2017-05-40"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterEndString, StringVal("2016-20-20"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterEndString, StringVal("2017-02-DD"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterEndString, StringVal("2016-02"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    QuarterEndString, StringVal("2017"), "Bad date or timestamp"
  );


  /*
    year_begin
  */

  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    YearBeginTimestamp, TimestampVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    YearBeginTimestamp, as_timestamp(2016,2,10,0,0,0), as_timestamp(2016,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    YearBeginTimestamp, as_timestamp(2017,2,10,0,0,0), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    YearBeginTimestamp, as_timestamp(2017,3,14,15,59,59), as_timestamp(2017,1,1,0,0,0)
  );

  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearBeginString, StringVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearBeginString, StringVal("2016-02-10 00:00:00"), as_timestamp(2016,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearBeginString, StringVal("2017-02-10 00:00:00"), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearBeginString, StringVal("2017-03-14 15:59:59"), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearBeginString, StringVal("2016-02-10"), as_timestamp(2016,1,1,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearBeginString, StringVal("2017-02-10"), as_timestamp(2017,1,1,0,0,0)
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearBeginString, StringVal("2017-05-40"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearBeginString, StringVal("2016-20-20"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearBeginString, StringVal("2017-02-DD"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearBeginString, StringVal("2016-02"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearBeginString, StringVal("2017"), "Bad date or timestamp"
  );


  /*
    year_end
  */

  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    YearEndTimestamp, TimestampVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    YearEndTimestamp, as_timestamp(2016,2,10,0,0,0), as_timestamp(2016,12,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    YearEndTimestamp, as_timestamp(2017,2,10,0,0,0), as_timestamp(2017,12,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal, TimestampVal>(
    YearEndTimestamp, as_timestamp(2017,3,14,15,59,59), as_timestamp(2017,12,31,0,0,0)
  );

  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearEndString, StringVal::null(), TimestampVal::null()
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearEndString, StringVal("2016-02-10 00:00:00"), as_timestamp(2016,12,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearEndString, StringVal("2017-02-10 00:00:00"), as_timestamp(2017,12,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearEndString, StringVal("2017-03-14 15:59:59"), as_timestamp(2017,12,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearEndString, StringVal("2016-02-10"), as_timestamp(2016,12,31,0,0,0)
  );
  passed &= UdfTestHarness::ValidateUdf<TimestampVal,StringVal >(
    YearEndString, StringVal("2017-02-10"), as_timestamp(2017,12,31,0,0,0)
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearEndString, StringVal("2017-05-40"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearEndString, StringVal("2016-20-20"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearEndString, StringVal("2017-02-DD"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearEndString, StringVal("2016-02"), "Bad date or timestamp"
  );
  passed &= ValidateUdfError<TimestampVal, StringVal>(
    YearEndString, StringVal("2017"), "Bad date or timestamp"
  );

  /* результат тестов */
  std::cout << "Tests " << (passed ? "Passed." : "Failed.") << std::endl;
  return !passed;
}
