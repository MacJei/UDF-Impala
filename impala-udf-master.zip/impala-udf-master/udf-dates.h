#ifndef DATES_UDF_H
#define DATES_UDF_H

#include <impala_udf/udf.h>

using namespace impala_udf;

// *Begin - функции возвращают дату начала периода, время выставляется в '00:00:00'
// *End - функции возвращают последнюю дату периода, время выставляется в '00:00:00'
//        чтобы корректно работало:
//            *_end('2017-03-14 15:00:00') between '2017-03-01' and '2017-03-31'
//        На Teradata *_end-функции также высталяют время в '00:00:00'.
const int32_t BEGIN_TIME_OF_DAY = 0; // '00:00:00.0'
const int32_t END_TIME_OF_DAY = 0; // '00:00:00.0'

const size_t DATE_STR_LEN = 10; // for 'YYYY-MM-DD'
const size_t TIMESTAMP_STR_LEN = 19; // for 'YYYY-MM-DD hh:mm:ss'


// Usage: > create function sys_lib.month_begin(timestamp) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='MonthBeginTimestamp';
//        > select month_begin('2017-03-14 00:00:00'); --'2017-03-01 00:00:00'
//        > select month_begin('2017-03-14 23:59:59'); --'2017-03-01 00:00:00'
//        > select month_begin(now());
TimestampVal MonthBeginTimestamp(FunctionContext* context, const TimestampVal& ts_val);

// Usage: > create function sys_lib.month_begin(string) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='MonthBeginString';
//        > select month_begin('2017-03-14 00:00:00'); --'2017-03-01 00:00:00'
//        > select month_begin('2017-03-14 23:59:59'); --'2017-03-01 00:00:00'
//        > select month_begin(now());
TimestampVal MonthBeginString(FunctionContext* context, const StringVal& str_val);


// Usage: > create function sys_lib.month_end(timestamp) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='MonthEndTimestamp';
//        > select month_end('2017-03-14 00:00:00'); --'2017-03-31 00:00:00'
//        > select month_end('2017-03-14 23:59:59'); --'2017-03-31 00:00:00'
//        > select month_end(now());
TimestampVal MonthEndTimestamp(FunctionContext* context, const TimestampVal& ts_val);

// Usage: > create function sys_lib.month_end(string) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='MonthEndString';
//        > select month_end('2017-03-14 00:00:00'); --'2017-03-31 00:00:00'
//        > select month_end('2017-03-14 23:59:59'); --'2017-03-31 00:00:00'
//        > select month_end(now());
TimestampVal MonthEndString(FunctionContext* context, const StringVal& str_val);


// Usage: > create function sys_lib.quarter_begin(timestamp) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='QuarterBeginTimestamp';
//        > select quarter_begin('2017-03-14 00:00:00'); --'2017-01-01 00:00:00'
//        > select quarter_begin('2017-02-14 23:59:59'); --'2017-01-01 00:00:00'
//        > select quarter_begin(now());
TimestampVal QuarterBeginTimestamp(FunctionContext* context, const TimestampVal& ts_val);

// Usage: > create function sys_lib.quarter_begin(string) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='QuarterBeginString';
//        > select quarter_begin('2017-03-14 00:00:00'); --'2017-01-01 00:00:00'
//        > select quarter_begin('2017-03-14 23:59:59'); --'2017-01-01 00:00:00'
//        > select quarter_begin(now());
TimestampVal QuarterBeginString(FunctionContext* context, const StringVal& str_val);


// Usage: > create function sys_lib.quarter_end(timestamp) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='QuarterEndTimestamp';
//        > select quarter_end('2017-03-14 00:00:00'); --'2017-03-31 00:00:00'
//        > select quarter_end('2017-02-14 23:59:59'); --'2017-03-31 00:00:00'
//        > select quarter_end(now());
TimestampVal QuarterEndTimestamp(FunctionContext* context, const TimestampVal& ts_val);

// Usage: > create function sys_lib.quarter_end(string) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='QuarterEndString';
//        > select quarter_end('2017-03-14 00:00:00'); --'2017-03-31 00:00:00'
//        > select quarter_end('2017-03-14 23:59:59'); --'2017-03-31 00:00:00'
//        > select quarter_end(now());
TimestampVal QuarterEndString(FunctionContext* context, const StringVal& str_val);


// Usage: > create function sys_lib.year_begin(timestamp) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='YearBeginTimestamp';
//        > select year_begin('2017-03-14 00:00:00'); --'2017-01-01 00:00:00'
//        > select year_begin('2017-02-14 23:59:59'); --'2017-01-01 00:00:00'
//        > select year_begin(now());
TimestampVal YearBeginTimestamp(FunctionContext* context, const TimestampVal& ts_val);

// Usage: > create function sys_lib.year_begin(string) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='YearBeginString';
//        > select year_begin('2017-03-14 00:00:00'); --'2017-01-01 00:00:00'
//        > select year_begin('2017-02-14 23:59:59'); --'2017-01-01 00:00:00'
//        > select year_begin(now());
TimestampVal YearBeginString(FunctionContext* context, const StringVal& str_val);


// Usage: > create function sys_lib.year_end(timestamp) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='YearEndTimestamp';
//        > select year_end('2017-03-14 00:00:00'); --'2017-12-31 00:00:00'
//        > select year_end('2017-02-14 23:59:59'); --'2017-12-31 00:00:00'
//        > select year_end(now());
TimestampVal YearEndTimestamp(FunctionContext* context, const TimestampVal& ts_val);

// Usage: > create function sys_lib.year_end(string) returns timestamp
//          location '/data/impala-udf/libudf-dates.so' SYMBOL='YearEndString';
//        > select year_end('2017-03-14 00:00:00'); --'2017-12-31 00:00:00'
//        > select year_end('2017-02-14 23:59:59'); --'2017-12-31 00:00:00'
//        > select year_end(now());
TimestampVal YearEndString(FunctionContext* context, const StringVal& str_val);

#endif
