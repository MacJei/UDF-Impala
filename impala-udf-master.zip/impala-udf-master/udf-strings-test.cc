#include <iostream>

#include <impala_udf/udf-test-harness.h>
#include "udf-strings.h"

using namespace impala;
using namespace impala_udf;
using namespace std;

int main(int argc, char** argv) {
  bool passed = true;

  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal>(
      length_ruutf8_str, StringVal("abUx"), StringVal("4"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal>(
      length_ruutf8_str, StringVal("абУх"), StringVal("4"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal>(
      length_ruutf8_str, StringVal("йцукен"), StringVal("6"));

  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal>(
      upper_ruutf8, StringVal("abUx"), StringVal("ABUX"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal>(
      upper_ruutf8, StringVal("абУх"), StringVal("АБУХ"));

  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal>(
      lower_ruutf8, StringVal("abUx"), StringVal("abux"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal>(
      lower_ruutf8, StringVal("абУх"), StringVal("абух"));

  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("1"), StringVal("6"), StringVal("qUertY"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("2"), StringVal("3"), StringVal("Uer"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("5"), StringVal("3"), StringVal("tY"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("1"), StringVal("0"), StringVal::null());
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("0"), StringVal("1"), StringVal::null());
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("-5"), StringVal("1"), StringVal("U"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("-4"), StringVal("2"), StringVal("er"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("-2"), StringVal("3"), StringVal("tY"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("йцУкеН"), StringVal("2"), StringVal("3"), StringVal("цУк"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("йцУкеН"), StringVal("5"), StringVal("3"), StringVal("еН"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("йцУкеН"), StringVal("-4"), StringVal("2"), StringVal("Ук"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("йцУкеН"), StringVal("-5"), StringVal("1"), StringVal("ц"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("йцУкеН"), StringVal("-6"), StringVal("3"), StringVal("йцУ"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("йцУкеН"), StringVal("1"), StringVal("6"), StringVal("йцУкеН"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal>(
      substr2_ruutf8_str, StringVal("qUertY"), StringVal("-3"), StringVal("rtY"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("6"), StringVal("3"), StringVal("Y"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("qUertY"), StringVal("7"), StringVal("3"), StringVal::null());
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal>(
      substr2_ruutf8_str, StringVal("йцУкеН"), StringVal("7"), StringVal::null());
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal>(
      substr2_ruutf8_str, StringVal("йцУкеН"), StringVal("6"), StringVal("Н"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("K9"), StringVal("3"), StringVal("7"), StringVal::null());

  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      substr_ruutf8_str, StringVal("йцУкеН"), StringVal("1"), StringVal("6"), StringVal("йцУкеН"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("a"), StringVal("b"), StringVal("c"), StringVal("a"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("abc"), StringVal("abc"), StringVal("xyz"), StringVal("xyz"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("abcde"), StringVal("ab"), StringVal("xy"), StringVal("xycde"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("abcde"), StringVal("abc"), StringVal("xyz"), StringVal("xyzde"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("abcdedcba"), StringVal("abc"), StringVal("xyz"), StringVal("xyzdedzyx"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("abcde"), StringVal("abc"), StringVal("xy"), StringVal("xyde"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("abcdedcba"), StringVal("abc"), StringVal(""), StringVal("ded"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("abcde"), StringVal(""), StringVal("xyz"), StringVal("abcde"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("абвгде"), StringVal("абв"), StringVal("эюя"), StringVal("эюягде"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("abc абв"), StringVal("ab аб"), StringVal("xy~эю"), StringVal("xyc~эюв"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("Card2Card"), StringVal("qwerенгшщASDFРОЛД"), StringVal("mnbячсмPIIYTЙЦУК"), StringVal("Caяd2Caяd"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("13, Majorova str."), StringVal("qwerенгшщASDFРОЛД"), StringVal("mnbячсмPIIYTЙЦУК"), StringVal("13, Majoяova stя."));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("ZABAYKALSKIY FILIAL OAO F"), StringVal("qwerенгшщASDFРОЛД"), StringVal("mnbячсмPIIYTЙЦУК"), StringVal("ZIBIYKILYKIY ЙILIIL OIO Й"));
  passed &= UdfTestHarness::ValidateUdf<StringVal, StringVal, StringVal, StringVal>(
      translate_ruutf8, StringVal("KFC PRIMORSKAYA  CAFE"), StringVal("qwerенгшщASDFРОЛД"), StringVal("mnbячсмPIIYTЙЦУК"), StringVal("KЙC PRIMORYKIYI  CIЙE"));

  cout << "Tests " << (passed ? "Passed." : "Failed.") << endl;
  return !passed;
}
