#include <iostream>
#include <boost/date_time/gregorian/gregorian.hpp>
#include "udf-dates.h"

using boost::gregorian::date;
using boost::gregorian::from_string;


// ParseDate парсит из строки год, месяц и день, возвращает все через parsed_*-параметры
// проверяем на соответствие формату "YYYY-MM-DD", на месте Y, M и D должны быть цифры
inline bool ParseDate(const StringVal& str_val, 
                      uint16_t &parsed_year, uint8_t &parsed_month, uint8_t &parsed_day) {
  // для проверки максимально возможного числа в конкретном месяце
  // текущая реализация черзе массив получается быстрее, чем сложная конструкция в if
  // в первую позицию кладем 0, т.к. нулевого месяца нет - if это учитывает в проверке ниже
  // вариант с 29.02 учтем ниже, тут укажем для частого случая - 28
  //                                 месяц: 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12
  const uint8_t last_day_in_month[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  const char *str = reinterpret_cast<const char*>(str_val.ptr);
  if (
    str_val.len >= 10
    && str[0] - '0' <= 9
    && str[1] - '0' <= 9
    && str[2] - '0' <= 9
    && str[3] - '0' <= 9
    && '-' == str[4]
    && str[5] - '0' <= 1
    && str[6] - '0' <= 9
    && '-' == str[7]
    && str[8] - '0' <= 3
    && str[9] - '0' <= 9
  ) {
    // извлекаем из строки год, месяц и день в переменные типа uint
    uint16_t year =  10 * (10 * (10 * (str[0]-'0') + str[1]-'0') + str[2]-'0') + str[3]-'0';
    uint8_t month = (str[5]-'0')*10 + (str[6]-'0');
    uint8_t   day = (str[8]-'0')*10 + (str[9]-'0');
    // проверяем, что год, месяц и день реальны - не выходят за границы
    if (
      1400 <= year && day != 0 && month <= 12 &&
      (
        ( day <= last_day_in_month[month]) || // если month == 0, то получим day <= 0 - false
        // если получили 29.02, то год должен быть високосным
        ( month==2 && day==29 && ((year%4 == 0 and year%100 != 0) or (year%400 == 0)) )
      )
    ) {
      // все прошло успешно,
      parsed_year = year;
      parsed_month = month;
      parsed_day = day;
      return true;
    }
  }
  return false;
}


/* 
  month_begin
*/

TimestampVal MonthBeginTimestamp(FunctionContext* context, const TimestampVal& ts_val) {
  if (ts_val.is_null) return TimestampVal::null();
  // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
  // поэтому введем указатель, через который сможем работать данными как с boost::gregorian::date
  const date* p_src_date = reinterpret_cast<const date*>(&ts_val.date);
  date trg_date(p_src_date->year(), p_src_date->month(), 1);
  // собираем новый TimestampVal, используем туже бинарную совместимость, время также выравниваем
  return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), BEGIN_TIME_OF_DAY);
}

TimestampVal MonthBeginString(FunctionContext* context, const StringVal& str_val) {
  if (str_val.is_null) return TimestampVal::null();
  if (str_val.len == DATE_STR_LEN || str_val.len == TIMESTAMP_STR_LEN) {
    uint16_t parsed_year;
    uint8_t parsed_month, parsed_day;
    if (ParseDate(str_val, parsed_year, parsed_month, parsed_day)) {
      date trg_date(parsed_year, parsed_month, 1);
      // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
      // время также выравниваем
      return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), BEGIN_TIME_OF_DAY);
    }
  }
  // если оказались тут, то что-то пошло не так - см. if выше
  context->SetError("Bad date or timestamp");
  return TimestampVal::null();
}


/* 
  month_end
*/

TimestampVal MonthEndTimestamp(FunctionContext* context, const TimestampVal& ts_val) {
  if (ts_val.is_null) return TimestampVal::null();
  // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
  // поэтому введем указатель, через который сможем работать данными как с boost::gregorian::date
  const date* p_src_date = reinterpret_cast<const date*>(&ts_val.date);
  date trg_date = p_src_date->end_of_month();
  // собираем новый TimestampVal, используем туже бинарную совместимость, время также выравниваем
  return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), END_TIME_OF_DAY);
}

TimestampVal MonthEndString(FunctionContext* context, const StringVal& str_val) {
  if (str_val.is_null) return TimestampVal::null();
  if (str_val.len == DATE_STR_LEN || str_val.len == TIMESTAMP_STR_LEN) {
    uint16_t parsed_year;
    uint8_t parsed_month, parsed_day;
    if (ParseDate(str_val, parsed_year, parsed_month, parsed_day)) {
      date src_date(parsed_year, parsed_month, parsed_day);
      date trg_date = src_date.end_of_month();
      // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
      // время также выравниваем
      return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), END_TIME_OF_DAY);
    }
  }
  // если оказались тут, то что-то пошло не так - см. if выше
  context->SetError("Bad date or timestamp");
  return TimestampVal::null();
}


/* 
  quarter_begin
*/

TimestampVal QuarterBeginTimestamp(FunctionContext* context, const TimestampVal& ts_val) {
  if (ts_val.is_null) return TimestampVal::null();
  // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
  // поэтому введем указатель, через который сможем работать данными как с boost::gregorian::date
  const date* src_date = reinterpret_cast<const date*>(&ts_val.date);
  const uint8_t month = src_date->month();
  date trg_date;
  if (month <= 3) { // Q1
    trg_date = date(src_date->year(), 1, 1);
  }
  else if (month <= 6) { // Q2
    trg_date = date(src_date->year(), 4, 1);
  }
  else if (month <= 9) { // Q3
    trg_date = date(src_date->year(), 7, 1);
  }
  else { // Q4
    trg_date = date(src_date->year(), 10, 1);
  }
  // собираем новый TimestampVal, используем туже бинарную совместимость, время также выравниваем
  return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), BEGIN_TIME_OF_DAY);
}

TimestampVal QuarterBeginString(FunctionContext* context, const StringVal& str_val) {
  if (str_val.is_null) return TimestampVal::null();
  if (str_val.len == DATE_STR_LEN || str_val.len == TIMESTAMP_STR_LEN) {
    uint16_t parsed_year;
    uint8_t parsed_month, parsed_day;
    if (ParseDate(str_val, parsed_year, parsed_month, parsed_day)) {
      date trg_date;
      if (parsed_month <= 3) { // Q1
        trg_date = date(parsed_year, 1, 1);
      }
      else if (parsed_month <= 6) { // Q2
        trg_date = date(parsed_year, 4, 1);
      }
      else if (parsed_month <= 9) { // Q3
        trg_date = date(parsed_year, 7, 1);
      }
      else { // Q4
        trg_date = date(parsed_year, 10, 1);
      }
      // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
      // время также выравниваем
      return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), BEGIN_TIME_OF_DAY);
    }
  }
  // если оказались тут, то что-то пошло не так - см. if выше
  context->SetError("Bad date or timestamp");
  return TimestampVal::null();
}


/* 
  quarter_end
*/

TimestampVal QuarterEndTimestamp(FunctionContext* context, const TimestampVal& ts_val) {
  if (ts_val.is_null) return TimestampVal::null();
  // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
  // поэтому введем указатель, через который сможем работать данными как с boost::gregorian::date
  const date* src_date = reinterpret_cast<const date*>(&ts_val.date);
  const uint8_t month = src_date->month();
  date trg_date;
  if (month <= 3) { // Q1
    trg_date = date(src_date->year(), 3, 31);
  }
  else if (month <= 6) { // Q2
    trg_date = date(src_date->year(), 6, 30);
  }
  else if (month <= 9) { // Q3
    trg_date = date(src_date->year(), 9, 30);
  }
  else { // Q4
    trg_date = date(src_date->year(), 12, 31);
  }
  // собираем новый TimestampVal, используем туже бинарную совместимость, время также выравниваем
  return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), END_TIME_OF_DAY);
}

TimestampVal QuarterEndString(FunctionContext* context, const StringVal& str_val) {
  if (str_val.is_null) return TimestampVal::null();
  if (str_val.len == DATE_STR_LEN || str_val.len == TIMESTAMP_STR_LEN) {
    uint16_t parsed_year;
    uint8_t parsed_month, parsed_day;
    if (ParseDate(str_val, parsed_year, parsed_month, parsed_day)) {
      date trg_date;
      if (parsed_month <= 3) { // Q1
        trg_date = date(parsed_year, 3, 31);
      }
      else if (parsed_month <= 6) { // Q2
        trg_date = date(parsed_year, 6, 30);
      }
      else if (parsed_month <= 9) { // Q3
        trg_date = date(parsed_year, 9, 30);
      }
      else { // Q4
        trg_date = date(parsed_year, 12, 31);
      }
      // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
      // время также выравниваем
      return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), END_TIME_OF_DAY);
    }
  }
  // если оказались тут, то что-то пошло не так - см. if выше
  context->SetError("Bad date or timestamp");
  return TimestampVal::null();
}


/* 
  year_begin
*/

TimestampVal YearBeginTimestamp(FunctionContext* context, const TimestampVal& ts_val) {
  if (ts_val.is_null) return TimestampVal::null();
  // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
  // поэтому введем указатель, через который сможем работать данными как с boost::gregorian::date
  const date* src_date = reinterpret_cast<const date*>(&ts_val.date);
  date trg_date(src_date->year(), 1, 1);
  // собираем новый TimestampVal, используем туже бинарную совместимость, время также выравниваем
  return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), BEGIN_TIME_OF_DAY);
}

TimestampVal YearBeginString(FunctionContext* context, const StringVal& str_val) {
  if (str_val.is_null) return TimestampVal::null();
  if (str_val.len == DATE_STR_LEN || str_val.len == TIMESTAMP_STR_LEN) {
    uint16_t parsed_year;
    uint8_t parsed_month, parsed_day;
    if (ParseDate(str_val, parsed_year, parsed_month, parsed_day)) {
      date trg_date(parsed_year, 1, 1);
      // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
      // время также выравниваем
      return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), BEGIN_TIME_OF_DAY);
    }
  }
  // если оказались тут, то что-то пошло не так - см. if выше
  context->SetError("Bad date or timestamp");
  return TimestampVal::null();
}


/* 
  year_end
*/

TimestampVal YearEndTimestamp(FunctionContext* context, const TimestampVal& ts_val) {
  if (ts_val.is_null) return TimestampVal::null();
  // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
  // поэтому введем указатель, через который сможем работать данными как с boost::gregorian::date
  const date* src_date = reinterpret_cast<const date*>(&ts_val.date);
  date trg_date(src_date->year(), 12, 31);
  // собираем новый TimestampVal, используем туже бинарную совместимость, время также выравниваем
  return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), END_TIME_OF_DAY);
}

TimestampVal YearEndString(FunctionContext* context, const StringVal& str_val) {
  if (str_val.is_null) return TimestampVal::null();
  if (str_val.len == DATE_STR_LEN || str_val.len == TIMESTAMP_STR_LEN) {
    uint16_t parsed_year;
    uint8_t parsed_month, parsed_day;
    if (ParseDate(str_val, parsed_year, parsed_month, parsed_day)) {
      date trg_date(parsed_year, 12, 31);
      // согласно документации TimestampVal::date бинарно совместим с boost::gregorian::date
      // время также выравниваем
      return TimestampVal(*(reinterpret_cast<int32_t*>(&trg_date)), END_TIME_OF_DAY);
    }
  }
  // если оказались тут, то что-то пошло не так - см. if выше
  context->SetError("Bad date or timestamp");
  return TimestampVal::null();
}
