#include <impala_udf/udf.h>

using namespace impala_udf;

// Usage: > create function translate(string, string, string, string) returns string
//          location '/data/impala-udf/libudf-strings.so' SYMBOL='translate';

StringVal translate_ruutf8(FunctionContext* context, const StringVal& p_input, const StringVal& p_from, const StringVal& p_to);
StringVal translate(FunctionContext* context, const StringVal& p_input, const StringVal& p_from, const StringVal& p_to, const StringVal& p_locale);

StringVal upper_ruutf8(FunctionContext* context, const StringVal& p_input);
StringVal upper(FunctionContext* context, const StringVal& p_input, const StringVal& p_locale);

StringVal lower_ruutf8(FunctionContext* context, const StringVal& p_input);
StringVal lower(FunctionContext* context, const StringVal& p_input, const StringVal& p_locale);

IntVal length_ruutf8(FunctionContext* context, const StringVal& p_input);
IntVal length(FunctionContext* context, const StringVal& p_input, const StringVal& p_locale);
// Only for test
StringVal length_ruutf8_str(FunctionContext* context, const StringVal& p_input);

StringVal substr_ruutf8(FunctionContext* context, const StringVal& p_input, const IntVal& p_from, const IntVal& p_length);
StringVal substr(FunctionContext* context, const StringVal& p_input, const IntVal& p_from, const IntVal& p_length, const StringVal& p_locale);
StringVal substr2(FunctionContext* context, const StringVal& p_input, const IntVal& p_from, const StringVal& p_locale);
StringVal substr2_ruutf8(FunctionContext* context, const StringVal& p_input, const IntVal& p_from);
// Only for test
StringVal substr_ruutf8_str(FunctionContext* context, const StringVal& p_input, const StringVal& p_from, const StringVal& p_length);
StringVal substr2_ruutf8_str(FunctionContext* context, const StringVal& p_input, const StringVal& p_from);
