// Copyright 2012 Cloudera Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "udf-crypto.h"

#include <cctype>
#include <cmath>
#include <string>   
#include "hex.h"
#include "sha.h"
#include "sha3.h"
#define CRYPTOPP_ENABLE_NAMESPACE_WEAK 1
#include <md5.h>
#include <iostream>

#include "common.h"

IMPALA_UDF_EXPORT
StringVal SHA1(FunctionContext* context, const StringVal& arg1) {
  if (arg1.is_null) return StringVal::null();
  CryptoPP::byte digest[CryptoPP::SHA1::DIGESTSIZE];
  CryptoPP::SHA1().CalculateDigest(digest, arg1.ptr, arg1.len);
  std::string encoded;

  CryptoPP::StringSource ss(digest, sizeof(digest), true,
      new CryptoPP::HexEncoder(
          new CryptoPP::StringSink(encoded)
      ) // HexEncoder
  ); // StringSource
  return StringVal::CopyFrom(context,
      reinterpret_cast<const uint8_t*>(encoded.c_str()), encoded.size());
}

IMPALA_UDF_EXPORT
StringVal MD5(FunctionContext* context, const StringVal& arg1) {
  if (arg1.is_null) return StringVal::null();
  CryptoPP::byte digest[CryptoPP::Weak::MD5::DIGESTSIZE];
  CryptoPP::Weak::MD5().CalculateDigest(digest, arg1.ptr, arg1.len);
  std::string encoded;

  CryptoPP::StringSource ss(digest, sizeof(digest), true,
      new CryptoPP::HexEncoder(
          new CryptoPP::StringSink(encoded)
      ) // HexEncoder
  ); // StringSource
  return StringVal::CopyFrom(context,
      reinterpret_cast<const uint8_t*>(encoded.c_str()), encoded.size());
}

IMPALA_UDF_EXPORT
StringVal SHA224(FunctionContext* context, const StringVal& arg1) {
  if (arg1.is_null) return StringVal::null();
  CryptoPP::byte digest[CryptoPP::SHA224::DIGESTSIZE];
  CryptoPP::SHA224().CalculateDigest(digest, arg1.ptr, arg1.len);
  std::string encoded;

  CryptoPP::StringSource ss(digest, sizeof(digest), true,
      new CryptoPP::HexEncoder(
          new CryptoPP::StringSink(encoded)
      ) // HexEncoder
  ); // StringSource
  return StringVal::CopyFrom(context,
      reinterpret_cast<const uint8_t*>(encoded.c_str()), encoded.size());
}

IMPALA_UDF_EXPORT
StringVal SHA256(FunctionContext* context, const StringVal& arg1) {
  if (arg1.is_null) return StringVal::null();
  CryptoPP::byte digest[CryptoPP::SHA256::DIGESTSIZE];
  CryptoPP::SHA256().CalculateDigest(digest, arg1.ptr, arg1.len);
  std::string encoded;

  CryptoPP::StringSource ss(digest, sizeof(digest), true,
      new CryptoPP::HexEncoder(
          new CryptoPP::StringSink(encoded)
      ) // HexEncoder
  ); // StringSource
  return StringVal::CopyFrom(context,
      reinterpret_cast<const uint8_t*>(encoded.c_str()), encoded.size());
}

IMPALA_UDF_EXPORT
StringVal SHA384(FunctionContext* context, const StringVal& arg1) {
  if (arg1.is_null) return StringVal::null();
  CryptoPP::byte digest[CryptoPP::SHA384::DIGESTSIZE];
  CryptoPP::SHA384().CalculateDigest(digest, arg1.ptr, arg1.len);
  std::string encoded;

  CryptoPP::StringSource ss(digest, sizeof(digest), true,
      new CryptoPP::HexEncoder(
          new CryptoPP::StringSink(encoded)
      ) // HexEncoder
  ); // StringSource
  return StringVal::CopyFrom(context,
      reinterpret_cast<const uint8_t*>(encoded.c_str()), encoded.size());
}

IMPALA_UDF_EXPORT
StringVal SHA512(FunctionContext* context, const StringVal& arg1) {
  if (arg1.is_null) return StringVal::null();
  CryptoPP::byte digest[CryptoPP::SHA512::DIGESTSIZE];
  CryptoPP::SHA512().CalculateDigest(digest, arg1.ptr, arg1.len);
  std::string encoded;

  CryptoPP::StringSource ss(digest, sizeof(digest), true,
      new CryptoPP::HexEncoder(
          new CryptoPP::StringSink(encoded)
      ) // HexEncoder
  ); // StringSource
  return StringVal::CopyFrom(context,
      reinterpret_cast<const uint8_t*>(encoded.c_str()), encoded.size());
}

IMPALA_UDF_EXPORT
StringVal SHA3(FunctionContext* context, const StringVal& arg1) {
  if (arg1.is_null) return StringVal::null();
  CryptoPP::byte digest[CryptoPP::SHA3_512::DIGESTSIZE];
  CryptoPP::SHA3_512().CalculateDigest(digest, arg1.ptr, arg1.len);
  std::string encoded;

  CryptoPP::StringSource ss(digest, sizeof(digest), true,
      new CryptoPP::HexEncoder(
          new CryptoPP::StringSink(encoded)
      ) // HexEncoder
  ); // StringSource
  return StringVal::CopyFrom(context,
      reinterpret_cast<const uint8_t*>(encoded.c_str()), encoded.size());
}